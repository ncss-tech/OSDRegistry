# OSDRegistry

[![R build status](https://github.com/ncss-tech/OSDRegistry/workflows/R-CMD-check/badge.svg)](https://github.com/ncss-tech/OSDRegistry/actions)
  
Version control solution for [Official Series Descriptions](https://soilseries.sc.egov.usda.gov/) (OSDs). 

Official "series" are soil types used by the USDA-NRCS and the National Cooperative Soil Survey program.
