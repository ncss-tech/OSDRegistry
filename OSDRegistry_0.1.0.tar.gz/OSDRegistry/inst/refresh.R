library(OSDRegistry)
refresh_registry()
